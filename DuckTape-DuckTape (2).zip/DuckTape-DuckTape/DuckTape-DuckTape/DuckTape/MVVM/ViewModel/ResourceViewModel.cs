﻿namespace SafePort.MVVM.ViewModel
{
    internal class ResourceViewModel
    {
    }
}
