﻿namespace SafePort.MVVM.ViewModel
{
    internal class InfoViewModel
    {
    }
}
