﻿namespace SafePort.MVVM.ViewModel
{
    internal class HomeViewModel
    {
    }
}
